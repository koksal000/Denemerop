import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type GamePhase = "menu" | "playing" | "paused" | "goal";
export type CameraMode = "follow" | "free" | "top";

export interface TeamJersey {
  id: string;
  name: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
}

export const TEAM_JERSEYS: TeamJersey[] = [
  {
    id: "trabzonspor",
    name: "Trabzonspor",
    primaryColor: "#6B1D1D",
    secondaryColor: "#1E3A5F",
    accentColor: "#FFFFFF",
  },
  {
    id: "fenerbahce",
    name: "Fenerbahçe",
    primaryColor: "#FFED00",
    secondaryColor: "#00205B",
    accentColor: "#FFFFFF",
  },
  {
    id: "galatasaray",
    name: "Galatasaray",
    primaryColor: "#FDB913",
    secondaryColor: "#C8102E",
    accentColor: "#FFFFFF",
  },
  {
    id: "besiktas",
    name: "Beşiktaş",
    primaryColor: "#000000",
    secondaryColor: "#FFFFFF",
    accentColor: "#FF0000",
  },
];

interface FootballState {
  phase: GamePhase;
  selectedTeam: TeamJersey;
  cameraMode: CameraMode;
  shotPower: number;
  isCharging: boolean;
  goals: number;
  attempts: number;
  gameTime: number;
  ballPosition: [number, number, number];
  playerPosition: [number, number, number];
  isMobile: boolean;

  setPhase: (phase: GamePhase) => void;
  setSelectedTeam: (team: TeamJersey) => void;
  setCameraMode: (mode: CameraMode) => void;
  setShotPower: (power: number) => void;
  setIsCharging: (charging: boolean) => void;
  incrementGoals: () => void;
  incrementAttempts: () => void;
  setGameTime: (time: number) => void;
  setBallPosition: (pos: [number, number, number]) => void;
  setPlayerPosition: (pos: [number, number, number]) => void;
  setIsMobile: (mobile: boolean) => void;
  resetGame: () => void;
  startGame: () => void;
}

export const useFootball = create<FootballState>()(
  subscribeWithSelector((set) => ({
    phase: "menu",
    selectedTeam: TEAM_JERSEYS[0],
    cameraMode: "follow",
    shotPower: 0,
    isCharging: false,
    goals: 0,
    attempts: 0,
    gameTime: 0,
    ballPosition: [0, 0.3, 0],
    playerPosition: [0, 0, 5],
    isMobile: false,

    setPhase: (phase) => set({ phase }),
    setSelectedTeam: (team) => set({ selectedTeam: team }),
    setCameraMode: (mode) => set({ cameraMode: mode }),
    setShotPower: (power) => set({ shotPower: Math.min(100, Math.max(0, power)) }),
    setIsCharging: (charging) => set({ isCharging: charging }),
    incrementGoals: () => set((state) => ({ goals: state.goals + 1 })),
    incrementAttempts: () => set((state) => ({ attempts: state.attempts + 1 })),
    setGameTime: (time) => set({ gameTime: time }),
    setBallPosition: (pos) => set({ ballPosition: pos }),
    setPlayerPosition: (pos) => set({ playerPosition: pos }),
    setIsMobile: (mobile) => set({ isMobile: mobile }),
    
    resetGame: () =>
      set({
        shotPower: 0,
        isCharging: false,
        goals: 0,
        attempts: 0,
        gameTime: 0,
        ballPosition: [0, 0.3, 0],
        playerPosition: [0, 0, 5],
      }),
    
    startGame: () =>
      set({
        phase: "playing",
        shotPower: 0,
        isCharging: false,
        goals: 0,
        attempts: 0,
        gameTime: 0,
        ballPosition: [0, 0.3, 0],
        playerPosition: [0, 0, 5],
      }),
  }))
);

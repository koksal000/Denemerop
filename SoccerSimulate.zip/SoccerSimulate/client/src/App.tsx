import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState, useCallback } from "react";
import { KeyboardControls } from "@react-three/drei";
import "@fontsource/inter";

import { 
  FootballField, 
  PhysicsProvider, 
  Ball, 
  Player, 
  CameraController, 
  Lights, 
  SimpleSky,
  GameHUD,
  GoalCelebration,
  MainMenu,
  TouchControls,
  ErrorBoundary,
  SoundManager,
  MuteButton,
  Controls
} from "./components/game";

import { useFootball } from "./lib/stores/useFootball";

const keyMap = [
  { name: Controls.forward, keys: ["KeyW", "ArrowUp"] },
  { name: Controls.back, keys: ["KeyS", "ArrowDown"] },
  { name: Controls.left, keys: ["KeyA", "ArrowLeft"] },
  { name: Controls.right, keys: ["KeyD", "ArrowRight"] },
  { name: Controls.kick, keys: ["Space"] },
];

function GameScene() {
  const { selectedTeam, incrementGoals, setPhase, phase } = useFootball();

  const handleGoal = useCallback(() => {
    if (phase === "playing") {
      incrementGoals();
      setPhase("goal");
      console.log("GOAL!");
    }
  }, [phase, incrementGoals, setPhase]);

  return (
    <>
      <CameraController />
      <Lights />
      <SimpleSky />
      
      <Suspense fallback={null}>
        <PhysicsProvider gravity={[0, -9.82, 0]}>
          <FootballField />
          <Ball onGoal={handleGoal} />
          {phase !== "menu" && <Player team={selectedTeam} />}
        </PhysicsProvider>
      </Suspense>
    </>
  );
}

function LoadingScreen() {
  return (
    <div className="fixed inset-0 bg-green-900 flex items-center justify-center z-50">
      <div className="text-center">
        <div className="text-6xl mb-4 animate-bounce">⚽</div>
        <div className="text-white text-2xl font-bold">Yükleniyor...</div>
        <div className="mt-4 w-48 h-2 bg-green-700 rounded-full overflow-hidden mx-auto">
          <div className="h-full bg-white animate-pulse" style={{ width: '60%' }} />
        </div>
      </div>
    </div>
  );
}

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const { phase } = useFootball();

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <ErrorBoundary>
      <div style={{ width: "100vw", height: "100vh", position: "relative", overflow: "hidden" }}>
        <KeyboardControls map={keyMap}>
          <Canvas
            shadows
            camera={{
              position: [0, 15, 20],
              fov: 60,
              near: 0.1,
              far: 500,
            }}
            gl={{
              antialias: true,
              powerPreference: "high-performance",
              alpha: false,
            }}
            dpr={[1, 1.5]}
          >
            <color attach="background" args={["#87CEEB"]} />
            <fog attach="fog" args={["#87CEEB", 50, 200]} />
            <GameScene />
          </Canvas>

          <MainMenu />
          <GameHUD />
          <GoalCelebration />
          <TouchControls />
          <MuteButton />
          <SoundManager />
        </KeyboardControls>
      </div>
    </ErrorBoundary>
  );
}

export default App;

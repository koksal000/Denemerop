import { createContext, useContext, useRef, useEffect, ReactNode } from "react";
import { useFrame } from "@react-three/fiber";
import * as CANNON from "cannon-es";

interface PhysicsContextType {
  world: CANNON.World;
  addBody: (body: CANNON.Body) => void;
  removeBody: (body: CANNON.Body) => void;
}

const PhysicsContext = createContext<PhysicsContextType | null>(null);

export function usePhysics() {
  const context = useContext(PhysicsContext);
  if (!context) {
    throw new Error("usePhysics must be used within PhysicsProvider");
  }
  return context;
}

interface PhysicsProviderProps {
  children: ReactNode;
  gravity?: [number, number, number];
}

export function PhysicsProvider({ children, gravity = [0, -9.82, 0] }: PhysicsProviderProps) {
  const worldRef = useRef<CANNON.World | null>(null);

  if (!worldRef.current) {
    const world = new CANNON.World();
    world.gravity.set(gravity[0], gravity[1], gravity[2]);
    world.broadphase = new CANNON.SAPBroadphase(world);
    world.allowSleep = true;
    world.defaultContactMaterial.friction = 0.3;
    world.defaultContactMaterial.restitution = 0.3;

    const groundMaterial = new CANNON.Material("ground");
    const ballMaterial = new CANNON.Material("ball");
    
    const ballGroundContact = new CANNON.ContactMaterial(ballMaterial, groundMaterial, {
      friction: 0.4,
      restitution: 0.6,
    });
    world.addContactMaterial(ballGroundContact);

    const groundBody = new CANNON.Body({
      type: CANNON.Body.STATIC,
      shape: new CANNON.Plane(),
      material: groundMaterial,
    });
    groundBody.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
    world.addBody(groundBody);

    worldRef.current = world;
  }

  useFrame((_, delta) => {
    if (worldRef.current) {
      const fixedTimeStep = 1 / 60;
      const maxSubSteps = 3;
      worldRef.current.step(fixedTimeStep, delta, maxSubSteps);
    }
  });

  const addBody = (body: CANNON.Body) => {
    worldRef.current?.addBody(body);
  };

  const removeBody = (body: CANNON.Body) => {
    worldRef.current?.removeBody(body);
  };

  return (
    <PhysicsContext.Provider value={{ world: worldRef.current!, addBody, removeBody }}>
      {children}
    </PhysicsContext.Provider>
  );
}

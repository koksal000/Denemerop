import { useEffect, useRef } from "react";
import { useAudio } from "@/lib/stores/useAudio";
import { useFootball } from "@/lib/stores/useFootball";

export function SoundManager() {
  const { setBackgroundMusic, setHitSound, setSuccessSound, playSuccess, playHit } = useAudio();
  const { phase } = useFootball();
  const initialized = useRef(false);
  const prevPhase = useRef(phase);

  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    const bgMusic = new Audio("/sounds/background.mp3");
    bgMusic.loop = true;
    bgMusic.volume = 0.3;
    setBackgroundMusic(bgMusic);

    const hitSnd = new Audio("/sounds/hit.mp3");
    hitSnd.volume = 0.5;
    setHitSound(hitSnd);

    const successSnd = new Audio("/sounds/success.mp3");
    successSnd.volume = 0.6;
    setSuccessSound(successSnd);
  }, []);

  useEffect(() => {
    if (prevPhase.current !== "goal" && phase === "goal") {
      playSuccess();
    }
    prevPhase.current = phase;
  }, [phase, playSuccess]);

  return null;
}

export function MuteButton() {
  const { isMuted, toggleMute, backgroundMusic } = useAudio();
  const { phase } = useFootball();

  const handleToggle = () => {
    toggleMute();
    if (backgroundMusic) {
      if (!isMuted) {
        backgroundMusic.pause();
      } else {
        backgroundMusic.play().catch(() => {});
      }
    }
  };

  if (phase === "menu") return null;

  return (
    <button
      onClick={handleToggle}
      className="fixed top-4 left-1/2 -translate-x-1/2 bg-black/70 hover:bg-black/80 text-white px-4 py-2 rounded-lg font-bold transition-all z-30"
    >
      {isMuted ? "🔇 Ses Kapalı" : "🔊 Ses Açık"}
    </button>
  );
}

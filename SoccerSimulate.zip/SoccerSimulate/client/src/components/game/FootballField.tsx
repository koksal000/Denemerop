import { useRef, useMemo } from "react";
import * as THREE from "three";
import { useTexture } from "@react-three/drei";

const FIELD_WIDTH = 40;
const FIELD_LENGTH = 60;
const GOAL_WIDTH = 7.32;
const GOAL_HEIGHT = 2.44;
const GOAL_DEPTH = 2;

export function FootballField() {
  const grassTexture = useTexture("/textures/grass.png");
  
  useMemo(() => {
    grassTexture.wrapS = grassTexture.wrapT = THREE.RepeatWrapping;
    grassTexture.repeat.set(8, 12);
  }, [grassTexture]);

  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[FIELD_WIDTH, FIELD_LENGTH]} />
        <meshStandardMaterial map={grassTexture} color="#228B22" />
      </mesh>

      <FieldLines />
      <Goal position={[0, 0, -FIELD_LENGTH / 2]} rotation={[0, 0, 0]} />
      <Goal position={[0, 0, FIELD_LENGTH / 2]} rotation={[0, Math.PI, 0]} />
      <FieldBoundaries />
    </group>
  );
}

function FieldLines() {
  const lineMaterial = useMemo(() => new THREE.LineBasicMaterial({ color: 0xffffff }), []);

  const lines = useMemo(() => {
    const halfWidth = FIELD_WIDTH / 2;
    const halfLength = FIELD_LENGTH / 2;
    const penaltyAreaWidth = 16.5;
    const penaltyAreaDepth = 16.5;
    const goalAreaWidth = 5.5;
    const goalAreaDepth = 5.5;
    const centerCircleRadius = 9.15;
    const penaltySpotDistance = 11;

    const allLines: THREE.Vector3[][] = [];

    allLines.push([
      new THREE.Vector3(-halfWidth, 0.01, -halfLength),
      new THREE.Vector3(halfWidth, 0.01, -halfLength),
      new THREE.Vector3(halfWidth, 0.01, halfLength),
      new THREE.Vector3(-halfWidth, 0.01, halfLength),
      new THREE.Vector3(-halfWidth, 0.01, -halfLength),
    ]);

    allLines.push([
      new THREE.Vector3(-halfWidth, 0.01, 0),
      new THREE.Vector3(halfWidth, 0.01, 0),
    ]);

    const circlePoints: THREE.Vector3[] = [];
    for (let i = 0; i <= 64; i++) {
      const angle = (i / 64) * Math.PI * 2;
      circlePoints.push(
        new THREE.Vector3(
          Math.cos(angle) * centerCircleRadius,
          0.01,
          Math.sin(angle) * centerCircleRadius
        )
      );
    }
    allLines.push(circlePoints);

    [-1, 1].forEach((side) => {
      allLines.push([
        new THREE.Vector3(-penaltyAreaWidth, 0.01, side * halfLength),
        new THREE.Vector3(-penaltyAreaWidth, 0.01, side * (halfLength - penaltyAreaDepth)),
        new THREE.Vector3(penaltyAreaWidth, 0.01, side * (halfLength - penaltyAreaDepth)),
        new THREE.Vector3(penaltyAreaWidth, 0.01, side * halfLength),
      ]);

      allLines.push([
        new THREE.Vector3(-goalAreaWidth, 0.01, side * halfLength),
        new THREE.Vector3(-goalAreaWidth, 0.01, side * (halfLength - goalAreaDepth)),
        new THREE.Vector3(goalAreaWidth, 0.01, side * (halfLength - goalAreaDepth)),
        new THREE.Vector3(goalAreaWidth, 0.01, side * halfLength),
      ]);

      const spotPoints: THREE.Vector3[] = [];
      for (let i = 0; i <= 16; i++) {
        const angle = (i / 16) * Math.PI * 2;
        spotPoints.push(
          new THREE.Vector3(
            Math.cos(angle) * 0.2,
            0.01,
            side * (halfLength - penaltySpotDistance) + Math.sin(angle) * 0.2
          )
        );
      }
      allLines.push(spotPoints);
    });

    return allLines;
  }, []);

  return (
    <group>
      {lines.map((linePoints, index) => (
        <line key={index}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              count={linePoints.length}
              array={new Float32Array(linePoints.flatMap((p) => [p.x, p.y, p.z]))}
              itemSize={3}
            />
          </bufferGeometry>
          <lineBasicMaterial color={0xffffff} linewidth={2} />
        </line>
      ))}
    </group>
  );
}

function Goal({ position, rotation }: { position: [number, number, number]; rotation: [number, number, number] }) {
  const postMaterial = useMemo(
    () => new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.3, roughness: 0.5 }),
    []
  );
  const netMaterial = useMemo(
    () => new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.3, side: THREE.DoubleSide }),
    []
  );

  const postRadius = 0.06;
  const halfGoalWidth = GOAL_WIDTH / 2;

  return (
    <group position={position} rotation={rotation}>
      <mesh position={[-halfGoalWidth, GOAL_HEIGHT / 2, 0]} castShadow>
        <cylinderGeometry args={[postRadius, postRadius, GOAL_HEIGHT, 16]} />
        <primitive object={postMaterial} attach="material" />
      </mesh>
      
      <mesh position={[halfGoalWidth, GOAL_HEIGHT / 2, 0]} castShadow>
        <cylinderGeometry args={[postRadius, postRadius, GOAL_HEIGHT, 16]} />
        <primitive object={postMaterial} attach="material" />
      </mesh>
      
      <mesh position={[0, GOAL_HEIGHT, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <cylinderGeometry args={[postRadius, postRadius, GOAL_WIDTH, 16]} />
        <primitive object={postMaterial} attach="material" />
      </mesh>
      
      <mesh position={[-halfGoalWidth, GOAL_HEIGHT / 2, -GOAL_DEPTH / 2]} castShadow>
        <cylinderGeometry args={[postRadius, postRadius, GOAL_DEPTH, 16]} />
        <primitive object={postMaterial} attach="material" />
      </mesh>
      <mesh position={[halfGoalWidth, GOAL_HEIGHT / 2, -GOAL_DEPTH / 2]} castShadow>
        <cylinderGeometry args={[postRadius, postRadius, GOAL_DEPTH, 16]} />
        <primitive object={postMaterial} attach="material" />
      </mesh>
      
      <mesh position={[-halfGoalWidth, GOAL_HEIGHT, -GOAL_DEPTH / 2]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[postRadius, postRadius, GOAL_DEPTH, 16]} />
        <primitive object={postMaterial} attach="material" />
      </mesh>
      <mesh position={[halfGoalWidth, GOAL_HEIGHT, -GOAL_DEPTH / 2]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[postRadius, postRadius, GOAL_DEPTH, 16]} />
        <primitive object={postMaterial} attach="material" />
      </mesh>

      <mesh position={[0, GOAL_HEIGHT / 2, -GOAL_DEPTH]}>
        <planeGeometry args={[GOAL_WIDTH, GOAL_HEIGHT]} />
        <primitive object={netMaterial} attach="material" />
      </mesh>
      <mesh position={[-halfGoalWidth, GOAL_HEIGHT / 2, -GOAL_DEPTH / 2]} rotation={[0, Math.PI / 2, 0]}>
        <planeGeometry args={[GOAL_DEPTH, GOAL_HEIGHT]} />
        <primitive object={netMaterial} attach="material" />
      </mesh>
      <mesh position={[halfGoalWidth, GOAL_HEIGHT / 2, -GOAL_DEPTH / 2]} rotation={[0, -Math.PI / 2, 0]}>
        <planeGeometry args={[GOAL_DEPTH, GOAL_HEIGHT]} />
        <primitive object={netMaterial} attach="material" />
      </mesh>
      <mesh position={[0, GOAL_HEIGHT, -GOAL_DEPTH / 2]} rotation={[Math.PI / 2, 0, 0]}>
        <planeGeometry args={[GOAL_WIDTH, GOAL_DEPTH]} />
        <primitive object={netMaterial} attach="material" />
      </mesh>
    </group>
  );
}

function FieldBoundaries() {
  const halfWidth = FIELD_WIDTH / 2 + 2;
  const halfLength = FIELD_LENGTH / 2 + 2;
  const wallHeight = 1;

  return (
    <group>
      <mesh position={[0, wallHeight / 2, -halfLength]} visible={false}>
        <boxGeometry args={[FIELD_WIDTH + 4, wallHeight, 0.5]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>
      <mesh position={[0, wallHeight / 2, halfLength]} visible={false}>
        <boxGeometry args={[FIELD_WIDTH + 4, wallHeight, 0.5]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>
      <mesh position={[-halfWidth, wallHeight / 2, 0]} visible={false}>
        <boxGeometry args={[0.5, wallHeight, FIELD_LENGTH + 4]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>
      <mesh position={[halfWidth, wallHeight / 2, 0]} visible={false}>
        <boxGeometry args={[0.5, wallHeight, FIELD_LENGTH + 4]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>
    </group>
  );
}

export { FIELD_WIDTH, FIELD_LENGTH, GOAL_WIDTH, GOAL_HEIGHT, GOAL_DEPTH };

import { useMemo } from "react";
import * as THREE from "three";
import { useTexture } from "@react-three/drei";

export function Sky() {
  const skyTexture = useTexture("/textures/sky.png");

  useMemo(() => {
    skyTexture.wrapS = skyTexture.wrapT = THREE.RepeatWrapping;
    skyTexture.repeat.set(2, 2);
  }, [skyTexture]);

  return (
    <mesh scale={[-1, 1, 1]}>
      <sphereGeometry args={[200, 32, 32]} />
      <meshBasicMaterial map={skyTexture} side={THREE.BackSide} />
    </mesh>
  );
}

export function SimpleSky() {
  return (
    <mesh scale={[-1, 1, 1]}>
      <sphereGeometry args={[200, 32, 32]} />
      <meshBasicMaterial color="#87CEEB" side={THREE.BackSide} />
    </mesh>
  );
}

import { useRef, useState } from "react";
import { useFootball } from "@/lib/stores/useFootball";

export function TouchControls() {
  const { isMobile, phase, isCharging, setIsCharging, setShotPower } = useFootball();
  const chargeStartTime = useRef(0);
  const chargeInterval = useRef<NodeJS.Timeout | null>(null);

  const [joystickActive, setJoystickActive] = useState(false);
  const [joystickPos, setJoystickPos] = useState({ x: 0, y: 0 });
  const joystickCenter = useRef({ x: 0, y: 0 });
  const joystickRef = useRef<HTMLDivElement>(null);

  const handleJoystickStart = (e: React.TouchEvent | React.MouseEvent) => {
    if (!joystickRef.current) return;
    
    const rect = joystickRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    joystickCenter.current = { x: centerX, y: centerY };
    setJoystickActive(true);
  };

  const handleJoystickMove = (e: React.TouchEvent | React.MouseEvent) => {
    if (!joystickActive) return;

    let clientX: number, clientY: number;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const maxDistance = 50;
    let dx = clientX - joystickCenter.current.x;
    let dy = clientY - joystickCenter.current.y;
    
    const distance = Math.sqrt(dx * dx + dy * dy);
    if (distance > maxDistance) {
      dx = (dx / distance) * maxDistance;
      dy = (dy / distance) * maxDistance;
    }

    setJoystickPos({ x: dx, y: dy });

    const normalizedX = dx / maxDistance;
    const normalizedY = dy / maxDistance;
    
    window.dispatchEvent(new CustomEvent('joystickmove', { 
      detail: { x: normalizedX, y: normalizedY } 
    }));
  };

  const handleJoystickEnd = () => {
    setJoystickActive(false);
    setJoystickPos({ x: 0, y: 0 });
    window.dispatchEvent(new CustomEvent('joystickmove', { 
      detail: { x: 0, y: 0 } 
    }));
  };

  const handleKickStart = () => {
    if (phase !== "playing") return;
    setIsCharging(true);
    chargeStartTime.current = Date.now();
    
    chargeInterval.current = setInterval(() => {
      const elapsed = (Date.now() - chargeStartTime.current) / 1000;
      const power = Math.min(100, elapsed * 50);
      setShotPower(power);
    }, 50);
  };

  const handleKickEnd = () => {
    if (!isCharging) return;
    
    if (chargeInterval.current) {
      clearInterval(chargeInterval.current);
    }

    window.dispatchEvent(new CustomEvent('mobilekick'));

    setIsCharging(false);
    setShotPower(0);
  };

  if (!isMobile || phase !== "playing") return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-20">
      <div 
        ref={joystickRef}
        className="absolute left-8 bottom-32 w-32 h-32 rounded-full bg-black/40 pointer-events-auto touch-none"
        onTouchStart={handleJoystickStart}
        onTouchMove={handleJoystickMove}
        onTouchEnd={handleJoystickEnd}
        onMouseDown={handleJoystickStart}
        onMouseMove={handleJoystickMove}
        onMouseUp={handleJoystickEnd}
        onMouseLeave={handleJoystickEnd}
      >
        <div 
          className="absolute w-16 h-16 rounded-full bg-white/80 border-4 border-gray-400 shadow-lg"
          style={{
            left: `calc(50% - 2rem + ${joystickPos.x}px)`,
            top: `calc(50% - 2rem + ${joystickPos.y}px)`,
            transition: joystickActive ? 'none' : 'all 0.2s ease-out'
          }}
        />
      </div>

      <button
        className={`absolute right-8 bottom-32 w-24 h-24 rounded-full pointer-events-auto touch-none flex items-center justify-center text-white text-xl font-bold shadow-lg transition-all ${
          isCharging 
            ? "bg-red-600 scale-110" 
            : "bg-green-600 hover:bg-green-700"
        }`}
        onTouchStart={handleKickStart}
        onTouchEnd={handleKickEnd}
        onMouseDown={handleKickStart}
        onMouseUp={handleKickEnd}
      >
        ⚽ ŞUT
      </button>

      <div className="absolute left-8 bottom-8 bg-black/60 text-white px-4 py-2 rounded-lg text-sm">
        Joystick ile hareket et
      </div>
    </div>
  );
}

import { useRef } from "react";
import * as THREE from "three";

export function Lights() {
  const directionalLightRef = useRef<THREE.DirectionalLight>(null);

  return (
    <>
      <ambientLight intensity={0.5} color="#ffffff" />
      
      <directionalLight
        ref={directionalLightRef}
        position={[20, 30, 20]}
        intensity={1.2}
        color="#ffffff"
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={100}
        shadow-camera-left={-40}
        shadow-camera-right={40}
        shadow-camera-top={40}
        shadow-camera-bottom={-40}
        shadow-bias={-0.0001}
      />
      
      <directionalLight
        position={[-15, 20, -15]}
        intensity={0.4}
        color="#87CEEB"
      />
      
      <hemisphereLight
        args={["#87CEEB", "#228B22", 0.3]}
      />
    </>
  );
}

import { useState } from "react";
import { useFootball, TEAM_JERSEYS, TeamJersey } from "@/lib/stores/useFootball";

export function MainMenu() {
  const { phase, selectedTeam, setSelectedTeam, startGame, setIsMobile } = useFootball();
  const [showTeamSelect, setShowTeamSelect] = useState(false);

  if (phase !== "menu") return null;

  const handleStartGame = () => {
    const isMobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth < 768;
    setIsMobile(isMobileDevice);
    startGame();
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-30 bg-gradient-to-b from-green-800/80 to-green-900/90">
      <div className="bg-white/95 rounded-2xl p-8 max-w-lg w-full mx-4 shadow-2xl">
        <h1 className="text-4xl font-bold text-center text-green-800 mb-2">
          ⚽ 3D Futbol
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Tek Oyunculu Deneyim
        </p>

        {!showTeamSelect ? (
          <div className="space-y-4">
            <div className="bg-gray-100 rounded-lg p-4">
              <div className="text-sm text-gray-600 mb-2">Seçili Takım:</div>
              <div className="flex items-center gap-4">
                <div 
                  className="w-12 h-12 rounded-full border-4 border-white shadow-md"
                  style={{ 
                    background: `linear-gradient(135deg, ${selectedTeam.primaryColor} 50%, ${selectedTeam.secondaryColor} 50%)` 
                  }}
                />
                <span className="text-xl font-bold">{selectedTeam.name}</span>
              </div>
            </div>

            <button
              onClick={() => setShowTeamSelect(true)}
              className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-bold transition-all"
            >
              🎽 Forma Değiştir
            </button>

            <button
              onClick={handleStartGame}
              className="w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-lg font-bold text-xl transition-all"
            >
              ▶️ Oyunu Başlat
            </button>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg text-sm text-gray-700">
              <div className="font-bold mb-2">🎮 Nasıl Oynanır:</div>
              <ul className="space-y-1 list-disc list-inside">
                <li>WASD veya yön tuşları ile hareket et</li>
                <li>BOŞLUK tuşuna basılı tutarak şut gücünü ayarla</li>
                <li>Topa yaklaşıp şut at</li>
                <li>Kaleye gol atmaya çalış!</li>
              </ul>
            </div>
          </div>
        ) : (
          <TeamSelector 
            selectedTeam={selectedTeam}
            onSelect={(team) => {
              setSelectedTeam(team);
              setShowTeamSelect(false);
            }}
            onBack={() => setShowTeamSelect(false)}
          />
        )}
      </div>
    </div>
  );
}

interface TeamSelectorProps {
  selectedTeam: TeamJersey;
  onSelect: (team: TeamJersey) => void;
  onBack: () => void;
}

function TeamSelector({ selectedTeam, onSelect, onBack }: TeamSelectorProps) {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-4">
        Takım Seç
      </h2>
      
      <div className="grid grid-cols-2 gap-4">
        {TEAM_JERSEYS.map((team) => (
          <button
            key={team.id}
            onClick={() => onSelect(team)}
            className={`p-4 rounded-lg border-4 transition-all ${
              selectedTeam.id === team.id
                ? "border-green-500 bg-green-50"
                : "border-gray-200 hover:border-gray-400 bg-white"
            }`}
          >
            <div 
              className="w-16 h-16 mx-auto rounded-full border-4 border-white shadow-lg mb-2"
              style={{ 
                background: `linear-gradient(135deg, ${team.primaryColor} 50%, ${team.secondaryColor} 50%)` 
              }}
            />
            <div className="font-bold text-center text-gray-800">
              {team.name}
            </div>
          </button>
        ))}
      </div>

      <button
        onClick={onBack}
        className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-bold transition-all mt-4"
      >
        ← Geri
      </button>
    </div>
  );
}

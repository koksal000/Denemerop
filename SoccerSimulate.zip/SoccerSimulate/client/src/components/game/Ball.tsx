import { useRef, useEffect, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import * as CANNON from "cannon-es";
import { usePhysics } from "./PhysicsWorld";
import { useFootball } from "@/lib/stores/useFootball";
import { FIELD_LENGTH, GOAL_WIDTH, GOAL_HEIGHT } from "./FootballField";

const BALL_RADIUS = 0.22;
const BALL_MASS = 0.43;
const AIR_DRAG = 0.03;
const ROLLING_RESISTANCE = 0.02;

interface BallProps {
  onGoal?: () => void;
}

export function Ball({ onGoal }: BallProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const bodyRef = useRef<CANNON.Body | null>(null);
  const { world, addBody, removeBody } = usePhysics();
  const { setBallPosition, phase, ballPosition } = useFootball();
  const lastGoalCheck = useRef(0);

  const ballMaterial = useMemo(() => new CANNON.Material("ball"), []);

  useEffect(() => {
    const shape = new CANNON.Sphere(BALL_RADIUS);
    const body = new CANNON.Body({
      mass: BALL_MASS,
      shape,
      material: ballMaterial,
      linearDamping: AIR_DRAG,
      angularDamping: ROLLING_RESISTANCE,
    });
    
    body.position.set(ballPosition[0], ballPosition[1], ballPosition[2]);
    bodyRef.current = body;
    addBody(body);

    return () => {
      if (bodyRef.current) {
        removeBody(bodyRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (phase === "playing" && bodyRef.current) {
      bodyRef.current.position.set(0, 0.3, 0);
      bodyRef.current.velocity.set(0, 0, 0);
      bodyRef.current.angularVelocity.set(0, 0, 0);
    }
  }, [phase]);

  useFrame(() => {
    if (bodyRef.current && meshRef.current) {
      meshRef.current.position.copy(bodyRef.current.position as any);
      meshRef.current.quaternion.copy(bodyRef.current.quaternion as any);

      setBallPosition([
        bodyRef.current.position.x,
        bodyRef.current.position.y,
        bodyRef.current.position.z,
      ]);

      const now = Date.now();
      if (now - lastGoalCheck.current > 500) {
        const ballZ = bodyRef.current.position.z;
        const ballX = bodyRef.current.position.x;
        const ballY = bodyRef.current.position.y;

        if (
          ballZ < -FIELD_LENGTH / 2 &&
          Math.abs(ballX) < GOAL_WIDTH / 2 &&
          ballY < GOAL_HEIGHT &&
          ballY > 0
        ) {
          onGoal?.();
          lastGoalCheck.current = now;
        }
      }

      const halfField = FIELD_LENGTH / 2 + 5;
      const halfWidth = 25;
      if (
        Math.abs(bodyRef.current.position.x) > halfWidth ||
        Math.abs(bodyRef.current.position.z) > halfField ||
        bodyRef.current.position.y < -5
      ) {
        bodyRef.current.position.set(0, 0.5, 0);
        bodyRef.current.velocity.set(0, 0, 0);
        bodyRef.current.angularVelocity.set(0, 0, 0);
      }
    }
  });

  const ballTexture = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext("2d")!;
    
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(0, 0, 256, 256);
    
    ctx.fillStyle = "#1a1a1a";
    const pentagonPositions = [
      [128, 60], [60, 120], [90, 200], [166, 200], [196, 120],
      [128, 128]
    ];
    
    pentagonPositions.forEach(([x, y]) => {
      ctx.beginPath();
      for (let i = 0; i < 5; i++) {
        const angle = (i * 72 - 90) * (Math.PI / 180);
        const px = x + 25 * Math.cos(angle);
        const py = y + 25 * Math.sin(angle);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
    });
    
    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true;
    return texture;
  }, []);

  return (
    <mesh ref={meshRef} castShadow receiveShadow>
      <sphereGeometry args={[BALL_RADIUS, 32, 32]} />
      <meshStandardMaterial map={ballTexture} roughness={0.4} metalness={0.1} />
    </mesh>
  );
}

export function useBallBody() {
  const { world } = usePhysics();
  
  const getBallBody = (): CANNON.Body | null => {
    for (let i = 0; i < world.bodies.length; i++) {
      const body = world.bodies[i];
      if (body.mass > 0 && body.shapes[0] instanceof CANNON.Sphere) {
        return body;
      }
    }
    return null;
  };

  const kickBall = (direction: THREE.Vector3, power: number) => {
    const ballBody = getBallBody();
    if (ballBody) {
      const force = direction.clone().multiplyScalar(power * 20);
      
      ballBody.velocity.set(force.x, force.y + power * 3, force.z);
      
      const spin = new CANNON.Vec3(
        (Math.random() - 0.5) * power * 2,
        (Math.random() - 0.5) * power * 2,
        (Math.random() - 0.5) * power * 2
      );
      ballBody.angularVelocity.copy(spin);
      
      console.log(`Ball kicked with power: ${power}, direction: ${direction.x.toFixed(2)}, ${direction.y.toFixed(2)}, ${direction.z.toFixed(2)}`);
    }
  };

  return { getBallBody, kickBall };
}

export { BALL_RADIUS };

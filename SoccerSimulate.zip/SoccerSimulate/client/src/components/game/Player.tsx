import { useRef, useMemo, useEffect, useCallback } from "react";
import { useFrame } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import * as THREE from "three";
import { useFootball, TeamJersey } from "@/lib/stores/useFootball";
import { useBallBody, BALL_RADIUS } from "./Ball";

const PLAYER_HEIGHT = 1.8;
const PLAYER_RADIUS = 0.3;
const MOVE_SPEED = 8;
const KICK_DISTANCE = 1.2;

enum Controls {
  forward = "forward",
  back = "back",
  left = "left",
  right = "right",
  kick = "kick",
}

interface PlayerProps {
  team: TeamJersey;
}

export function Player({ team }: PlayerProps) {
  const groupRef = useRef<THREE.Group>(null);
  const { 
    phase, 
    setPlayerPosition, 
    ballPosition, 
    shotPower, 
    setShotPower, 
    isCharging, 
    setIsCharging,
    incrementAttempts,
    isMobile
  } = useFootball();
  
  const { kickBall } = useBallBody();
  const [, getKeys] = useKeyboardControls<Controls>();
  const velocity = useRef(new THREE.Vector3());
  const chargeStartTime = useRef(0);
  const joystickInput = useRef({ x: 0, y: 0 });
  const kickFnRef = useRef<() => void>(() => {});

  const jerseyTexture = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 512;
    const ctx = canvas.getContext("2d")!;

    const gradient = ctx.createLinearGradient(0, 0, 256, 0);
    gradient.addColorStop(0, team.primaryColor);
    gradient.addColorStop(0.5, team.secondaryColor);
    gradient.addColorStop(1, team.primaryColor);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 256, 256);

    ctx.fillStyle = team.primaryColor === "#000000" ? "#333333" : "#222222";
    ctx.fillRect(0, 256, 256, 256);

    ctx.fillStyle = team.accentColor;
    ctx.font = "bold 60px Arial";
    ctx.textAlign = "center";
    ctx.fillText("10", 128, 180);

    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true;
    return texture;
  }, [team]);

  const performKickAction = useCallback(() => {
    if (!groupRef.current) return;

    const playerPos = groupRef.current.position;
    const ballPos = new THREE.Vector3(ballPosition[0], ballPosition[1], ballPosition[2]);
    const distanceToBall = playerPos.distanceTo(ballPos);

    if (distanceToBall < KICK_DISTANCE + BALL_RADIUS + PLAYER_RADIUS) {
      const direction = new THREE.Vector3()
        .subVectors(ballPos, playerPos)
        .normalize();
      
      direction.y = 0.3 + (shotPower / 100) * 0.4;
      direction.normalize();

      kickBall(direction, shotPower / 100 * 15 + 5);
      incrementAttempts();
      console.log(`Kicked ball with power: ${shotPower}`);
    } else {
      console.log(`Too far from ball: ${distanceToBall.toFixed(2)}m`);
    }

    setIsCharging(false);
    setShotPower(0);
  }, [ballPosition, shotPower, kickBall, incrementAttempts, setIsCharging, setShotPower]);

  kickFnRef.current = performKickAction;

  useEffect(() => {
    const handleJoystickMove = (e: CustomEvent) => {
      joystickInput.current = e.detail;
    };

    const handleMobileKick = () => {
      if (phase === "playing") {
        kickFnRef.current();
      }
    };

    window.addEventListener('joystickmove', handleJoystickMove as EventListener);
    window.addEventListener('mobilekick', handleMobileKick as EventListener);
    
    return () => {
      window.removeEventListener('joystickmove', handleJoystickMove as EventListener);
      window.removeEventListener('mobilekick', handleMobileKick as EventListener);
    };
  }, [phase]);

  useEffect(() => {
    if (isMobile) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === "Space" && !isCharging && phase === "playing") {
        setIsCharging(true);
        chargeStartTime.current = Date.now();
        console.log("Starting kick charge");
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === "Space" && isCharging && phase === "playing") {
        kickFnRef.current();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [isCharging, phase, isMobile, setIsCharging]);

  useFrame((_, delta) => {
    if (!groupRef.current || phase !== "playing") return;

    if (isCharging && !isMobile) {
      const elapsed = (Date.now() - chargeStartTime.current) / 1000;
      const power = Math.min(100, elapsed * 50);
      setShotPower(power);
    }

    const moveDir = new THREE.Vector3();

    if (isMobile) {
      const { x, y } = joystickInput.current;
      if (Math.abs(x) > 0.1 || Math.abs(y) > 0.1) {
        moveDir.x = x;
        moveDir.z = y;
      }
    } else {
      const keys = getKeys();
      if (keys.forward) moveDir.z -= 1;
      if (keys.back) moveDir.z += 1;
      if (keys.left) moveDir.x -= 1;
      if (keys.right) moveDir.x += 1;
    }

    if (moveDir.length() > 0) {
      moveDir.normalize();
      velocity.current.lerp(moveDir.multiplyScalar(MOVE_SPEED), 0.1);
    } else {
      velocity.current.lerp(new THREE.Vector3(), 0.1);
    }

    groupRef.current.position.x += velocity.current.x * delta;
    groupRef.current.position.z += velocity.current.z * delta;

    groupRef.current.position.x = Math.max(-18, Math.min(18, groupRef.current.position.x));
    groupRef.current.position.z = Math.max(-28, Math.min(28, groupRef.current.position.z));

    if (velocity.current.length() > 0.1) {
      const targetRotation = Math.atan2(velocity.current.x, velocity.current.z);
      groupRef.current.rotation.y = THREE.MathUtils.lerp(
        groupRef.current.rotation.y,
        targetRotation,
        0.1
      );
    }

    setPlayerPosition([
      groupRef.current.position.x,
      groupRef.current.position.y,
      groupRef.current.position.z,
    ]);
  });

  return (
    <group ref={groupRef} position={[0, 0, 5]}>
      <mesh position={[0, PLAYER_HEIGHT / 2, 0]} castShadow>
        <capsuleGeometry args={[PLAYER_RADIUS, PLAYER_HEIGHT - PLAYER_RADIUS * 2, 8, 16]} />
        <meshStandardMaterial map={jerseyTexture} />
      </mesh>

      <mesh position={[0, PLAYER_HEIGHT + 0.15, 0]} castShadow>
        <sphereGeometry args={[0.15, 16, 16]} />
        <meshStandardMaterial color="#FFD5A5" />
      </mesh>
    </group>
  );
}

export { Controls };

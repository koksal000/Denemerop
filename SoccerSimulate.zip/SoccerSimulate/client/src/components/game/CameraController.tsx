import { useRef, useEffect } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { useFootball, CameraMode } from "@/lib/stores/useFootball";

const CAMERA_OFFSET_FOLLOW = new THREE.Vector3(0, 8, 12);
const CAMERA_OFFSET_TOP = new THREE.Vector3(0, 35, 0.01);
const CAMERA_SMOOTHING = 0.05;

export function CameraController() {
  const { camera } = useThree();
  const { ballPosition, playerPosition, cameraMode, phase } = useFootball();
  const targetPosition = useRef(new THREE.Vector3());
  const targetLookAt = useRef(new THREE.Vector3());
  const currentPosition = useRef(new THREE.Vector3(0, 15, 20));
  const currentLookAt = useRef(new THREE.Vector3(0, 0, 0));
  const isDragging = useRef(false);
  const previousMouse = useRef({ x: 0, y: 0 });
  const orbitAngles = useRef({ theta: 0, phi: Math.PI / 4 });
  const orbitDistance = useRef(20);

  useEffect(() => {
    const handleMouseDown = (e: MouseEvent) => {
      if (cameraMode === "free") {
        isDragging.current = true;
        previousMouse.current = { x: e.clientX, y: e.clientY };
      }
    };

    const handleMouseUp = () => {
      isDragging.current = false;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging.current && cameraMode === "free") {
        const deltaX = e.clientX - previousMouse.current.x;
        const deltaY = e.clientY - previousMouse.current.y;
        
        orbitAngles.current.theta -= deltaX * 0.005;
        orbitAngles.current.phi = Math.max(
          0.1,
          Math.min(Math.PI / 2 - 0.1, orbitAngles.current.phi + deltaY * 0.005)
        );
        
        previousMouse.current = { x: e.clientX, y: e.clientY };
      }
    };

    const handleWheel = (e: WheelEvent) => {
      if (cameraMode === "free") {
        orbitDistance.current = Math.max(5, Math.min(50, orbitDistance.current + e.deltaY * 0.05));
      }
    };

    window.addEventListener("mousedown", handleMouseDown);
    window.addEventListener("mouseup", handleMouseUp);
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("wheel", handleWheel);

    return () => {
      window.removeEventListener("mousedown", handleMouseDown);
      window.removeEventListener("mouseup", handleMouseUp);
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("wheel", handleWheel);
    };
  }, [cameraMode]);

  useFrame(() => {
    if (phase === "menu") {
      const menuPosition = new THREE.Vector3(0, 20, 30);
      const menuLookAt = new THREE.Vector3(0, 0, 0);
      
      currentPosition.current.lerp(menuPosition, 0.02);
      currentLookAt.current.lerp(menuLookAt, 0.02);
      
      camera.position.copy(currentPosition.current);
      camera.lookAt(currentLookAt.current);
      return;
    }

    const ballPos = new THREE.Vector3(ballPosition[0], ballPosition[1], ballPosition[2]);
    const playerPos = new THREE.Vector3(playerPosition[0], playerPosition[1], playerPosition[2]);

    switch (cameraMode) {
      case "follow": {
        const midPoint = new THREE.Vector3()
          .addVectors(ballPos, playerPos)
          .multiplyScalar(0.5);
        
        targetPosition.current.copy(playerPos).add(CAMERA_OFFSET_FOLLOW);
        targetLookAt.current.copy(midPoint);
        break;
      }
      
      case "top": {
        targetPosition.current.set(0, CAMERA_OFFSET_TOP.y, CAMERA_OFFSET_TOP.z);
        targetLookAt.current.set(0, 0, 0);
        break;
      }
      
      case "free": {
        const { theta, phi } = orbitAngles.current;
        const dist = orbitDistance.current;
        
        targetPosition.current.set(
          dist * Math.sin(phi) * Math.sin(theta),
          dist * Math.cos(phi),
          dist * Math.sin(phi) * Math.cos(theta)
        ).add(ballPos);
        
        targetLookAt.current.copy(ballPos);
        break;
      }
    }

    currentPosition.current.lerp(targetPosition.current, CAMERA_SMOOTHING);
    currentLookAt.current.lerp(targetLookAt.current, CAMERA_SMOOTHING);

    camera.position.copy(currentPosition.current);
    camera.lookAt(currentLookAt.current);
  });

  return null;
}

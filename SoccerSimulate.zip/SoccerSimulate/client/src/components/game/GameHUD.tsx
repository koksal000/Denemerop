import { useEffect, useRef } from "react";
import { useFootball, TEAM_JERSEYS } from "@/lib/stores/useFootball";

export function GameHUD() {
  const { 
    phase, 
    shotPower, 
    isCharging, 
    goals, 
    attempts, 
    gameTime,
    setGameTime,
    cameraMode,
    setCameraMode,
    isMobile
  } = useFootball();
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (phase === "playing") {
      timerRef.current = setInterval(() => {
        setGameTime(gameTime + 1);
      }, 1000);
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [phase, gameTime, setGameTime]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  if (phase !== "playing" && phase !== "goal") return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-10">
      <div className="absolute top-4 left-4 bg-black/70 text-white p-4 rounded-lg pointer-events-auto">
        <div className="text-2xl font-bold mb-2">
          ⚽ Goller: {goals}
        </div>
        <div className="text-lg">
          Denemeler: {attempts}
        </div>
        <div className="text-lg mt-2">
          ⏱️ {formatTime(gameTime)}
        </div>
      </div>

      <div className="absolute top-4 right-4 flex flex-col gap-2 pointer-events-auto">
        <button
          onClick={() => setCameraMode("follow")}
          className={`px-4 py-2 rounded-lg font-bold transition-all ${
            cameraMode === "follow" 
              ? "bg-green-600 text-white" 
              : "bg-gray-700 text-white hover:bg-gray-600"
          }`}
        >
          📹 Takip
        </button>
        <button
          onClick={() => setCameraMode("top")}
          className={`px-4 py-2 rounded-lg font-bold transition-all ${
            cameraMode === "top" 
              ? "bg-green-600 text-white" 
              : "bg-gray-700 text-white hover:bg-gray-600"
          }`}
        >
          🔝 Üstten
        </button>
        <button
          onClick={() => setCameraMode("free")}
          className={`px-4 py-2 rounded-lg font-bold transition-all ${
            cameraMode === "free" 
              ? "bg-green-600 text-white" 
              : "bg-gray-700 text-white hover:bg-gray-600"
          }`}
        >
          🎮 Serbest
        </button>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
        <div className="bg-black/70 rounded-lg p-4 min-w-[300px]">
          <div className="text-white text-center mb-2 font-bold">
            Şut Gücü
          </div>
          <div className="h-6 bg-gray-700 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-100 ${
                shotPower < 33 ? "bg-green-500" : 
                shotPower < 66 ? "bg-yellow-500" : 
                "bg-red-500"
              }`}
              style={{ width: `${shotPower}%` }}
            />
          </div>
          <div className="text-white text-center mt-2 text-sm">
            {isCharging ? `${Math.round(shotPower)}%` : "BOŞLUK tuşuna basılı tut"}
          </div>
        </div>
      </div>

      {!isMobile && (
        <div className="absolute bottom-8 left-4 bg-black/70 text-white p-4 rounded-lg text-sm">
          <div className="font-bold mb-2">Kontroller:</div>
          <div>W/↑ - İleri</div>
          <div>S/↓ - Geri</div>
          <div>A/← - Sol</div>
          <div>D/→ - Sağ</div>
          <div>BOŞLUK - Şut (basılı tut)</div>
        </div>
      )}

      <ResetButton />
    </div>
  );
}

function ResetButton() {
  const { resetGame, startGame } = useFootball();

  const handleReset = () => {
    resetGame();
    setTimeout(() => startGame(), 100);
  };

  return (
    <button
      onClick={handleReset}
      className="absolute bottom-8 right-4 bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-bold transition-all pointer-events-auto"
    >
      🔄 Sıfırla
    </button>
  );
}

export function GoalCelebration() {
  const { phase, setPhase } = useFootball();

  useEffect(() => {
    if (phase === "goal") {
      const timer = setTimeout(() => {
        setPhase("playing");
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [phase, setPhase]);

  if (phase !== "goal") return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-20 pointer-events-none">
      <div className="bg-green-600/90 text-white px-12 py-8 rounded-2xl animate-bounce">
        <div className="text-6xl font-bold text-center">⚽ GOL! ⚽</div>
      </div>
    </div>
  );
}
